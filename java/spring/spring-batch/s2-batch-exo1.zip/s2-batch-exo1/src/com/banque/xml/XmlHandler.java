package com.banque.xml;

/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
import java.io.File;
import java.sql.Timestamp;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.AbstractEntity;
import com.banque.entity.CompteEntity;
import com.banque.entity.ICompteEntity;
import com.banque.entity.IEntity;
import com.banque.entity.IOperationEntity;
import com.banque.entity.IUtilisateurEntity;
import com.banque.entity.OperationEntity;
import com.banque.entity.UtilisateurEntity;

/**
 * Exemple d'utilisation de JAX-B.
 */
public final class XmlHandler {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Va ecrire un fichier XML avec l'objet dedans.
	 *
	 * @param unObjet
	 *            un objet a ecrire
	 * @param unNomDeFichier
	 *            le nom du fichier, sera cree si il n'existe pas, ecrase sinon
	 * @throws JAXBException
	 *             si un probleme survient
	 */
	public static void ecrire(IEntity unObjet, String unNomDeFichier) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(AbstractEntity.class, CompteEntity.class,
				OperationEntity.class, UtilisateurEntity.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		jaxbMarshaller.marshal(unObjet, new File(unNomDeFichier));
	}

	/**
	 * Va lire un fichier XML pour en extraire l'objet.
	 *
	 * @param unNomDeFichier
	 *            le nom du fichier lu, doit exister
	 * @return l'objet lu
	 * @throws JAXBException
	 *             si un probleme survient
	 */
	public static IEntity lire(String unNomDeFichier) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(AbstractEntity.class, CompteEntity.class,
				OperationEntity.class, UtilisateurEntity.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		return (IEntity) jaxbUnmarshaller.unmarshal(new File(unNomDeFichier));
	}

	/**
	 * Lancement des tests XMLs
	 *
	 * @param args
	 *            ne sert a rien
	 */
	public static void main(String[] args) {
		XmlHandler.LOG.info("-- Debut -- ");
		final String uFn = "c:/temp/utilisateur.xml";
		final String cFn = "c:/temp/compte.xml";
		final String oFn = "c:/temp/operation.xml";

		IUtilisateurEntity utilisateur = new UtilisateurEntity(Integer.valueOf(45));
		utilisateur.setNom("Smith");
		utilisateur.setPrenom("Jhon");
		utilisateur.setLogin("alpha");
		utilisateur.setDerniereConnection(new Timestamp(System.currentTimeMillis()));
		utilisateur.setPassword("bonjour");
		utilisateur.setSex(Boolean.TRUE);
		utilisateur.setAdresse("Quelque part dans le test");
		utilisateur.setCodePostal(Integer.valueOf(78000));
		utilisateur.setDateDeNaissance(1, 1, 1988);
		utilisateur.setTelephone("0148759678");

		ICompteEntity compte = new CompteEntity(Integer.valueOf(25), "Livret A", Double.valueOf(5000d), null,
				Double.valueOf(0.0015d));
		compte.setUtilisateurId(utilisateur.getId());

		IOperationEntity operation = new OperationEntity(Integer.valueOf(15), new Timestamp(System.currentTimeMillis()),
				"Virement", Double.valueOf(50d));
		operation.setCompteId(compte.getId());

		try {
			XmlHandler.LOG.debug("Ecriture des fichiers XML");
			XmlHandler.ecrire(utilisateur, uFn);
			XmlHandler.ecrire(compte, cFn);
			XmlHandler.ecrire(operation, oFn);
		} catch (JAXBException e) {
			XmlHandler.LOG.error("Erreur", e);
			System.exit(-1);
		}

		try {
			XmlHandler.LOG.debug("Lecture des fichiers XML");

			XmlHandler.LOG.debug(XmlHandler.lire(uFn));
			XmlHandler.LOG.debug(XmlHandler.lire(cFn));
			XmlHandler.LOG.debug(XmlHandler.lire(oFn));
		} catch (JAXBException e) {
			XmlHandler.LOG.error("Erreur", e);
			System.exit(-1);
		}

		XmlHandler.LOG.info("-- Fin -- ");
		System.exit(0);
	}

}
