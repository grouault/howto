/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.xml;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Timestamp adapter pour JAXB.<br/>
 * Permet de gerer proprement les dates. <br/>
 */
public class TimestampAdapter extends XmlAdapter<String, Timestamp> {
	private static final Logger LOG = LogManager.getLogger();

	private static final String DATE_PATTERN = "dd/MM/yyyy HH:mm:ss";
	private SimpleDateFormat dateFormat;

	/**
	 * Constructor of the object.
	 */
	public TimestampAdapter() {
		super();
		this.dateFormat = new SimpleDateFormat(TimestampAdapter.DATE_PATTERN);
		this.dateFormat.setLenient(false);
	}

	@Override
	public Timestamp unmarshal(String aV) throws Exception {
		TimestampAdapter.LOG.trace("unmarshal valeur={}", aV);
		if (aV == null || aV.trim().isEmpty()) {
			return null;
		}
		java.util.Date result = null;
		// SimpleDateFormat n'etant pas thread safe il est preferable de
		// l'utiliser dans un bloque synchronise
		synchronized (this.dateFormat) {
			result = this.dateFormat.parse(aV);
		}
		java.sql.Timestamp resultat = null;
		if (result != null) {
			resultat = new java.sql.Timestamp(result.getTime());
		}
		TimestampAdapter.LOG.trace("unmarshal resultat={}", resultat);
		return resultat;

	}

	@Override
	public String marshal(Timestamp aV) throws Exception {
		TimestampAdapter.LOG.trace("marshal valeur={}", aV);
		if (aV == null) {
			return null;
		}
		String result = null;
		// SimpleDateFormat n'etant pas thread safe il est preferable de
		// l'utiliser dans un bloque synchronise
		synchronized (this.dateFormat) {
			result = this.dateFormat.format(aV);
		}
		TimestampAdapter.LOG.trace("marshal resultat={}", result);
		return result;
	}

}
