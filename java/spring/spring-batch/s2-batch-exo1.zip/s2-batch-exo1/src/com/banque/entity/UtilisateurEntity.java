/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.entity;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.banque.xml.SqlDateAdapter;
import com.banque.xml.TimestampAdapter;

/**
 * Le bean qui represente un utilisateur. <br>
 */
@XmlRootElement(name = "utilisateur")
public class UtilisateurEntity extends AbstractEntity implements IUtilisateurEntity {

	private static final long serialVersionUID = 1L;
	@XmlElement
	private String login;
	@XmlElement
	private String password;
	@XmlElement
	private String nom;
	@XmlElement
	private String prenom;
	@XmlElement
	private String adresse;
	@XmlElement
	private String telephone;
	@XmlElement
	private Integer codePostal;
	@XmlAttribute
	private Boolean sex;
	@XmlElement
	@XmlJavaTypeAdapter(value = TimestampAdapter.class)
	private Timestamp derniereConnection;
	@XmlElement
	@XmlJavaTypeAdapter(value = SqlDateAdapter.class)
	private java.sql.Date dateDeNaissance;

	/**
	 * Constructeur de l'objet. <br>
	 */
	public UtilisateurEntity() {
		this(null);
	}

	/**
	 * Constructeur de l'objet. <br>
	 *
	 * @param unId
	 *            l'id d'un utilisateur
	 */
	public UtilisateurEntity(Integer unId) {
		super(unId);
	}

	@Override
	public Boolean getSex() {
		return this.sex;
	}

	@Override
	public void setSex(Boolean pSex) {
		this.sex = pSex;
	}

	@Override
	public String getLogin() {
		return this.login;
	}

	@Override
	public void setLogin(String pLogin) {
		this.login = pLogin;
	}

	@Override
	public String getPassword() {
		return this.password;
	}

	@Override
	public void setPassword(String pPassword) {
		this.password = pPassword;
	}

	@Override
	public String getNom() {
		return this.nom;
	}

	@Override
	public void setNom(String pNom) {
		this.nom = pNom;
	}

	@Override
	public String getPrenom() {
		return this.prenom;
	}

	@Override
	public void setPrenom(String pPrenom) {
		this.prenom = pPrenom;
	}

	@Override
	public Timestamp getDerniereConnection() {
		return this.derniereConnection;
	}

	@Override
	public void setDerniereConnection(Timestamp pDerniereConnection) {
		this.derniereConnection = pDerniereConnection;
	}

	@Override
	public String getAdresse() {
		return this.adresse;
	}

	@Override
	public void setAdresse(String pAdresse) {
		if ((pAdresse == null) || pAdresse.trim().isEmpty()) {
			this.adresse = null;
		} else {
			this.adresse = pAdresse;
		}
	}

	@Override
	public String getTelephone() {
		return this.telephone;
	}

	@Override
	public void setTelephone(String pTelephone) {
		if ((pTelephone == null) || pTelephone.trim().isEmpty()) {
			this.telephone = null;
		} else {
			this.telephone = pTelephone;
		}
	}

	@Override
	public Integer getCodePostal() {
		return this.codePostal;
	}

	@Override
	public void setCodePostal(Integer pCodePostal) {
		this.codePostal = pCodePostal;
	}

	@Override
	public java.sql.Date getDateDeNaissance() {
		return this.dateDeNaissance;
	}

	@Override
	public void setDateDeNaissance(java.sql.Date pDateDeNaissance) {
		this.dateDeNaissance = pDateDeNaissance;
	}

	@Override
	public void setDateDeNaissance(int unJour, int unMois, int uneAnnee) {
		Calendar calendar = new GregorianCalendar();
		calendar.set(Calendar.YEAR, uneAnnee);
		// Mois commence a zero
		calendar.set(Calendar.MONTH, unMois - 1);
		calendar.set(Calendar.DAY_OF_MONTH, unJour);
		this.setDateDeNaissance(new java.sql.Date(calendar.getTimeInMillis()));
	}

	@Override
	protected String asString() {
		StringBuilder sb = new StringBuilder();
		sb.append("sex=");
		sb.append(this.getSex());
		sb.append(",nom=");
		sb.append(this.getNom());
		sb.append(",prenom=");
		sb.append(this.getPrenom());
		sb.append(",login=");
		sb.append(this.getLogin());
		sb.append(",adresse=");
		sb.append(this.getAdresse());
		sb.append(",codePostal=");
		sb.append(this.getCodePostal());
		sb.append(",telephone=");
		sb.append(this.getTelephone());
		sb.append(",dateDeNaissance=");
		sb.append(this.getDateDeNaissance());
		sb.append(",derniereConnection=");
		sb.append(this.getDerniereConnection());
		return sb.toString();
	}
}