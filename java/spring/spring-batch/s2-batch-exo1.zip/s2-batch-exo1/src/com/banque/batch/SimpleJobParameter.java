package com.banque.batch;

import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersIncrementer;

public class SimpleJobParameter implements JobParametersIncrementer {

	public JobParameters getNext(JobParameters aP) {
		long id = 1L;
		// Si pas de parametres = premier lancement du job
		if (aP == null || aP.isEmpty()) {
			// On ne fait rien id = 1
		} else {
			// Sinon on incremente l'id
			id = aP.getLong("run.id", 1L) + 1L;
		}
		return new JobParametersBuilder().addLong("run.id", id).toJobParameters();
	}
}
