/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.dao.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.banque.entity.IUtilisateurEntity;
import com.banque.entity.UtilisateurEntity;

/**
 * Objet utilitaire pour le JDBC spring.
 */
public class UtilisateurJdbcMapper implements RowMapper<IUtilisateurEntity> {

	/**
	 * Constructeur de l'objet.
	 */
	public UtilisateurJdbcMapper() {
		super();
	}

	@Override
	public IUtilisateurEntity mapRow(ResultSet rs, int id) throws SQLException {
		IUtilisateurEntity result = new UtilisateurEntity();
		result.setId(Integer.valueOf(rs.getInt("id")));
		result.setNom(rs.getString("nom"));
		result.setPrenom(rs.getString("prenom"));
		result.setLogin(rs.getString("login"));
		result.setPassword(rs.getString("password"));
		// Gestion de l'enumeration
		boolean sex = rs.getBoolean("sex");
		result.setSex(sex);
		result.setDerniereConnection(rs.getTimestamp("derniereConnection"));
		result.setAdresse(rs.getString("adresse"));
		int cp = rs.getInt("codePostal");
		if (rs.wasNull()) {
			result.setCodePostal(null);
		} else {
			result.setCodePostal(Integer.valueOf(cp));
		}
		result.setTelephone(rs.getString("telephone"));
		result.setDateDeNaissance(rs.getDate("dateDeNaissance"));
		return result;
	}

}
