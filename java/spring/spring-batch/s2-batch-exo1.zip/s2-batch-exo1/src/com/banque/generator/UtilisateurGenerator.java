/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.generator;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.IUtilisateurEntity;
import com.banque.entity.UtilisateurEntity;

/**
 * Classe utilitaire qui va generer des utilisateurs a partir des fichiers de
 * donnees.
 */
public final class UtilisateurGenerator {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur.
	 */
	private UtilisateurGenerator() {
		throw new IllegalAccessError("Classe utilitaire");
	}

	/**
	 * Genere les utilisateurs.
	 *
	 * @param combien
	 *            le nombre d'utilisateur
	 * @return la liste des utilisateurs
	 */
	public static List<IUtilisateurEntity> generateUtilisateurs(int combien) {
		List<String> noms = BanqueFileReader.lireNom();
		List<String> prenomsH = BanqueFileReader.lirePrenomHomme();
		List<String> prenomsF = BanqueFileReader.lirePrenomFemmes();
		List<String> adresse = BanqueFileReader.lireAdresses();
		Map<Integer, List<String>> villes = BanqueFileReader.lireVilles();
		Random random = new Random();
		int userId = 1000;
		List<IUtilisateurEntity> resultat = new ArrayList<IUtilisateurEntity>(combien);
		for (int i = 0; i < combien; i++) {
			UtilisateurGenerator.LOG.debug("Fabrication de l'utilisateur {}/{}", String.valueOf(i),
					String.valueOf(combien));
			IUtilisateurEntity utilisateur = new UtilisateurEntity(Integer.valueOf(userId));
			utilisateur.setNom(noms.get(random.nextInt(noms.size())));
			boolean sex = random.nextBoolean();
			utilisateur.setSex(sex);
			if (sex) {
				utilisateur.setPrenom(prenomsH.get(random.nextInt(prenomsH.size())));
			} else {
				utilisateur.setPrenom(prenomsF.get(random.nextInt(prenomsF.size())));
			}
			utilisateur.setAdresse(adresse.get(random.nextInt(adresse.size())));
			// 1000 a 98890
			List<String> nomVilles = null;
			int cp = -1;
			while (nomVilles == null) {
				cp = random.nextInt(98890 + 1);
				nomVilles = villes.get(Integer.valueOf(cp));
			}
			utilisateur.setCodePostal(Integer.valueOf(cp));
			utilisateur.setAdresse(utilisateur.getAdresse() + " " + nomVilles.get(random.nextInt(nomVilles.size())));
			utilisateur.setLogin(UUID.randomUUID().toString().substring(0, 8));
			utilisateur.setPassword(UUID.randomUUID().toString().substring(0, 12));
			if (random.nextBoolean()) {
				utilisateur.setDerniereConnection(new Timestamp(System.currentTimeMillis()));
			}
			if (random.nextBoolean()) {
				utilisateur.setDateDeNaissance(random.nextInt(31) + 1, random.nextInt(12) + 1,
						random.nextInt(55) + 1950);
			}
			if (random.nextBoolean()) {
				StringBuilder nu = new StringBuilder();
				for (int j = 0; j < 10; j++) {
					nu.append(random.nextInt(10));
				}
				utilisateur.setTelephone(nu.toString());
			}
			resultat.add(utilisateur);
			userId++;
		}
		return resultat;
	}

	/**
	 * Lancement de la generation du fichier plat.
	 *
	 * @param args
	 *            ne sert a rien
	 */
	public static void main(String[] args) {
		UtilisateurGenerator.LOG.info("-- Debut -- ");
		final String nomFichierSortie = "utilisateurs.csv";
		final Path pathFichierSortie = Paths.get(BanqueFileReader.ROOT, "in_out", nomFichierSortie);
		final int nbUtilisateurs = 100;
		final char delimiter = ';';
		List<IUtilisateurEntity> lu = UtilisateurGenerator.generateUtilisateurs(nbUtilisateurs);
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

			List<String> lignes = new ArrayList<String>(nbUtilisateurs);
			for (IUtilisateurEntity unUser : lu) {
				StringBuffer b = new StringBuffer();
				b.append(unUser.getId()).append(delimiter);
				b.append(unUser.getLogin()).append(delimiter);
				b.append(unUser.getPassword()).append(delimiter);
				b.append(unUser.getSex()).append(delimiter);
				b.append(unUser.getNom()).append(delimiter);
				b.append(unUser.getPrenom()).append(delimiter);
				b.append(unUser.getAdresse()).append(delimiter);
				b.append(unUser.getCodePostal()).append(delimiter);
				if (unUser.getTelephone() != null) {
					b.append(unUser.getTelephone()).append(delimiter);
				} else {
					b.append(delimiter);
				}
				if (unUser.getDateDeNaissance() != null) {
					b.append(sdf.format(unUser.getDateDeNaissance())).append(delimiter);
				} else {
					b.append(delimiter);
				}
				if (unUser.getDerniereConnection() != null) {
					b.append(sdf2.format(unUser.getDerniereConnection())).append(delimiter);
				} else {
					b.append(delimiter);
				}
				// On retire le dernier delimiter
				b.delete(b.length()-1, b.length());
				lignes.add(b.toString());
			}
			UtilisateurGenerator.LOG.printf(Level.INFO, "Ecriture des fichiers CSV dans %s", pathFichierSortie);
			Files.write(pathFichierSortie, lignes);
		} catch (Exception e) {
			UtilisateurGenerator.LOG.error("Erreur", e);
			System.exit(-1);
		}

		UtilisateurGenerator.LOG.info("-- Fin -- ");
		System.exit(0);
	}
}
