/*
 * Copyright : Ferret Renaud 2002
 *
 * @version 1.0
 */
package com.banque.batch.fieldset;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import com.banque.entity.IUtilisateurEntity;
import com.banque.entity.UtilisateurEntity;

/**
 * Classe responsable de la lecture du fichier plat pour le transformer en objet IUtilisateurEntity. <br/>
 *
 * Attention à l'ordre des colonnes dans le fichier plat. <br/>
 *
 * Ici on gere les colonnes a la main.
 */
public class UtilisateurFieldSetMapper implements FieldSetMapper<IUtilisateurEntity> {
	private static final Logger LOG = LogManager.getLogger();

	@Override
	public IUtilisateurEntity mapFieldSet(FieldSet fieldSet) {
		IUtilisateurEntity resultat = new UtilisateurEntity	();
		resultat.setId(fieldSet.readInt(0));
		resultat.setLogin(fieldSet.readString(1));
		resultat.setPassword(fieldSet.readString(2));
		resultat.setSex(fieldSet.readBoolean(3));
		resultat.setNom(fieldSet.readString(4));
		resultat.setPrenom(fieldSet.readString(5));
		resultat.setAdresse(fieldSet.readString(6));
		resultat.setCodePostal(fieldSet.readInt(7));
		String tel =fieldSet.readString(8);
		if ((tel!=null) && !tel.trim().isEmpty()) {
			resultat.setTelephone(tel);
		}

		String dn = fieldSet.readString(9);
		if ((dn!=null) && !dn.trim().isEmpty()) {
			SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy");
			Date d= null;
			try {
				d = date.parse(dn);
			} catch (ParseException e) {
				UtilisateurFieldSetMapper.LOG.error("Erreur dans le parsing de la date de naissance", e);
			}
			if (d!=null) {
				resultat.setDateDeNaissance(new java.sql.Date(d.getTime()));
			}
		}

		String dlc = fieldSet.readString(10);
		if ((dlc!=null) && !dlc.trim().isEmpty()) {
			SimpleDateFormat heure = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date d = null;
			try {
				d = heure.parse(dlc);
			} catch (ParseException e) {
				UtilisateurFieldSetMapper.LOG.error("Erreur dans le parsing de la date de derniere connexion", e);
			}
			if (d != null) {
				resultat.setDerniereConnection(new Timestamp(d.getTime()));
			}
		}

		return resultat;
	}

}