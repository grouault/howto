/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.entity;

import java.sql.Timestamp;

/**
 * Represente un utilisateur.
 */
public interface IUtilisateurEntity extends IEntity {

	/**
	 * Recupere la propriete <i>sex</i>.
	 *
	 * @return la valeur de la propriete (voir ESex).
	 */
	Boolean getSex();

	/**
	 * Fixe la propriete <i>sex</i>.
	 *
	 * @param pSex
	 *            la nouvelle valeur pour la propriete sex.
	 */
	void setSex(Boolean pSex);

	/**
	 * Recupere la propriete <i>login</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	String getLogin();

	/**
	 * Fixe la propriete <i>login</i>.
	 *
	 * @param pLogin
	 *            la nouvelle valeur pour la propriete login.
	 */
	void setLogin(String pLogin);

	/**
	 * Recupere la propriete <i>password</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	String getPassword();

	/**
	 * Fixe la propriete <i>password</i>.
	 *
	 * @param pPassword
	 *            la nouvelle valeur pour la propriete password.
	 */
	void setPassword(String pPassword);

	/**
	 * Recupere la propriete <i>nom</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	String getNom();

	/**
	 * Fixe la propriete <i>nom</i>.
	 *
	 * @param pNom
	 *            la nouvelle valeur pour la propriete nom.
	 */
	void setNom(String pNom);

	/**
	 * Recupere la propriete <i>prenom</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	String getPrenom();

	/**
	 * Fixe la propriete <i>prenom</i>.
	 *
	 * @param pPrenom
	 *            la nouvelle valeur pour la propriete prenom.
	 */
	void setPrenom(String pPrenom);

	/**
	 * Recupere la propriete <i>derniereConnection</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	Timestamp getDerniereConnection();

	/**
	 * Fixe la propriete <i>derniereConnection</i>.
	 *
	 * @param pDerniereConnection
	 *            la nouvelle valeur pour la propriete derniereConnection.
	 */
	void setDerniereConnection(Timestamp pDerniereConnection);

	/**
	 * Recupere la propriete <i>adresse</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	String getAdresse();

	/**
	 * Fixe la propriete <i>adresse</i>.
	 *
	 * @param pAdresse
	 *            la nouvelle valeur pour la propriete adresse.
	 */
	void setAdresse(String pAdresse);

	/**
	 * Recupere la propriete <i>telephone</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	String getTelephone();

	/**
	 * Fixe la propriete <i>telephone</i>.
	 *
	 * @param pTelephone
	 *            la nouvelle valeur pour la propriete telephone.
	 */
	void setTelephone(String pTelephone);

	/**
	 * Recupere la propriete <i>codePostal</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	Integer getCodePostal();

	/**
	 * Fixe la propriete <i>codePostal</i>.
	 *
	 * @param pCodePostal
	 *            la nouvelle valeur pour la propriete codePostal.
	 */
	void setCodePostal(Integer pCodePostal);

	/**
	 * Recupere la propriete <i>dateDeNaissance</i>.
	 *
	 * @return la valeur de la propriete.
	 */
	java.sql.Date getDateDeNaissance();

	/**
	 * Fixe la propriete <i>dateDeNaissance</i>.
	 *
	 * @param pDateDeNaissance
	 *            la nouvelle valeur pour la propriete dateDeNaissance.
	 */
	void setDateDeNaissance(java.sql.Date pDateDeNaissance);

	/**
	 * Fixe la propriete <i>dateDeNaissance</i>.
	 *
	 * @param unJour
	 *            jour dans le mois de naissance (1 a 31)
	 * @param unMois
	 *            mois de naissance (1 a 12)
	 * @param uneAnnee
	 *            annee de naissance (ex: 2005)
	 */
	void setDateDeNaissance(int unJour, int unMois, int uneAnnee);

}