/*
 * Copyright : Ferret Renaud 2002
 *
 * @version 1.0
 */
package com.banque.batch.processor;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.item.ItemProcessor;

import com.banque.entity.IUtilisateurEntity;

/**
 * Item processor pour les utilisateurs
 */
public class UtilisateurItemProcessor implements ItemProcessor<IUtilisateurEntity, IUtilisateurEntity> {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur.
	 */
	public UtilisateurItemProcessor() {
		super();
	}

	@Override
	public IUtilisateurEntity process(IUtilisateurEntity unItem) throws Exception {
		// Aucun traitement specifique dans cette exemple
		UtilisateurItemProcessor.LOG.printf(Level.INFO, "Manipulation de %d", unItem.getId());
		return unItem;
	}

}