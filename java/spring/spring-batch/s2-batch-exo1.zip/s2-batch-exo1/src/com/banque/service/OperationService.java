/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banque.dao.ICompteDAO;
import com.banque.dao.IOperationDAO;
import com.banque.dao.ex.ExceptionDao;
import com.banque.entity.ICompteEntity;
import com.banque.entity.IOperationEntity;
import com.banque.entity.OperationEntity;
import com.banque.service.ex.AucunDroitException;
import com.banque.service.ex.DecouvertException;
import com.banque.service.ex.EntityIntrouvableException;
import com.banque.service.ex.ErreurTechniqueException;

/**
 * Gestion des operations.
 */
@Service
public class OperationService extends AbstractService implements IOperationService {
	private static final Logger LOG = LogManager.getLogger();
	@Autowired
	private IOperationDAO operationDao;
	@Autowired
	private ICompteDAO compteDao;

	/**
	 * Constructeur de l'objet.
	 */
	public OperationService() {
		super();
	}

	/**
	 * Recupere la propriete <i>compteDao</i>.
	 *
	 * @return the compteDao la valeur de la propriete.
	 */
	public ICompteDAO getCompteDao() {
		return this.compteDao;
	}

	/**
	 * Fixe la propriete <i>compteDao</i>.
	 *
	 * @param pCompteDao
	 *            la nouvelle valeur pour la propriete compteDao.
	 */
	public void setCompteDao(ICompteDAO pCompteDao) {
		this.compteDao = pCompteDao;
	}

	/**
	 * Recupere la propriete <i>operationDao</i>.
	 *
	 * @return the operationDao la valeur de la propriete.
	 */
	public IOperationDAO getOperationDao() {
		return this.operationDao;
	}

	/**
	 * Fixe la propriete <i>operationDao</i>.
	 *
	 * @param pOperationDao
	 *            la nouvelle valeur pour la propriete operationDao.
	 */
	public void setOperationDao(IOperationDAO pOperationDao) {
		this.operationDao = pOperationDao;
	}

	@Override
	public IOperationEntity select(Integer unUtilisateurId, Integer unCompteId, Integer uneOperationId)
			throws EntityIntrouvableException, AucunDroitException, NullPointerException, ErreurTechniqueException {
		OperationService.LOG.debug("select operation uId={} cpId={} opId={}", unUtilisateurId, unCompteId,
				uneOperationId);

		if (unUtilisateurId == null) {
			throw new NullPointerException("utilisateurId");
		}
		if (unCompteId == null) {
			throw new NullPointerException("compteId");
		}
		if (uneOperationId == null) {
			throw new NullPointerException("operationId");
		}

		// On verifie que le compte appartient bien a l'utilisateur
		ICompteEntity compte = null;
		try {
			compte = this.getCompteDao().select(unCompteId);
		} catch (ExceptionDao e) {
			throw new ErreurTechniqueException(e);
		}
		if (compte == null) {
			throw new EntityIntrouvableException();
		}
		if (!unUtilisateurId.equals(compte.getUtilisateurId())) {
			throw new AucunDroitException();
		}

		IOperationEntity resultat = null;
		try {
			resultat = this.getOperationDao().select(uneOperationId);
		} catch (ExceptionDao e) {
			throw new ErreurTechniqueException(e);
		}
		if (resultat == null) {
			throw new EntityIntrouvableException();
		}
		if (!unCompteId.equals(resultat.getCompteId())) {
			throw new AucunDroitException();
		}
		OperationService.LOG.debug("select operation resultat={}", resultat);
		return resultat;
	}

	@Override
	public List<IOperationEntity> selectAll(Integer unUtilisateurId, Integer unCompteId)
			throws EntityIntrouvableException, AucunDroitException, NullPointerException, ErreurTechniqueException {
		OperationService.LOG.debug("selectAll operation uId={} cpId={}", unUtilisateurId, unCompteId);

		if (unUtilisateurId == null) {
			throw new NullPointerException("utilisateurId");
		}
		if (unCompteId == null) {
			throw new NullPointerException("compteId");
		}

		ICompteEntity compte;
		try {
			compte = this.getCompteDao().select(unCompteId);
		} catch (ExceptionDao e) {
			throw new ErreurTechniqueException(e);
		}
		if (compte == null) {
			throw new EntityIntrouvableException();
		}
		if (!unUtilisateurId.equals(compte.getUtilisateurId())) {
			throw new AucunDroitException();
		}

		List<IOperationEntity> resultat = new ArrayList<IOperationEntity>();
		try {
			resultat = this.getOperationDao().selectAll("compteId=" + unCompteId, "date DESC");
		} catch (ExceptionDao e) {
			throw new ErreurTechniqueException(e);
		}
		OperationService.LOG.debug("selectAll trouve {} operation(s)", String.valueOf(resultat.size()));
		return resultat;
	}

	@Override
	public List<IOperationEntity> selectCritere(Integer unUtilisateurId, Integer unCompteId, Date unDebut, Date uneFin,
			boolean pCredit, boolean pDebit)
					throws EntityIntrouvableException, AucunDroitException, NullPointerException, ErreurTechniqueException {
		OperationService.LOG.debug("selectCritere operation uId={} cpId={} debut={} fin={} credit={} debit={}",
				unUtilisateurId, unCompteId, unDebut, uneFin, String.valueOf(pCredit), String.valueOf(pDebit));

		if (unUtilisateurId == null) {
			throw new NullPointerException("utilisateurId");
		}
		if (unCompteId == null) {
			throw new NullPointerException("compteId");
		}
		Boolean crediDebit = null;
		if (pCredit && !pDebit) {
			crediDebit = Boolean.TRUE;
		} else if (!pCredit && pDebit) {
			crediDebit = Boolean.FALSE;
		}

		List<IOperationEntity> resultat = new ArrayList<IOperationEntity>();
		try {
			resultat = this.getOperationDao().selectCriteria(unCompteId, unDebut, uneFin, crediDebit);
		} catch (ExceptionDao e) {
			throw new ErreurTechniqueException(e);
		}
		OperationService.LOG.debug("selectCritere trouve {} operation(s)", String.valueOf(resultat.size()));
		return resultat;
	}

	@Override
	public List<IOperationEntity> faireVirement(Integer unUtilisateurId, Integer unCompteIdSrc, Integer unCompteIdDst,
			Double unMontant) throws EntityIntrouvableException, AucunDroitException, NullPointerException,
	DecouvertException, ErreurTechniqueException {
		OperationService.LOG.debug("faireVirement uId={} cpIdSrc={} cpIdDest={}", String.valueOf(unUtilisateurId),
				String.valueOf(unCompteIdSrc), String.valueOf(unCompteIdDst));

		if (unUtilisateurId == null) {
			throw new NullPointerException("utilisateurId");
		}
		if (unCompteIdSrc == null) {
			throw new NullPointerException("compteIdSrc");
		}
		if (unCompteIdDst == null) {
			throw new NullPointerException("compteIdDst");
		}
		if (unMontant == null) {
			throw new NullPointerException("montant");
		}
		List<IOperationEntity> resultat = new ArrayList<IOperationEntity>(2);
		IOperationEntity opSrc = null;
		IOperationEntity opDst = null;
		try {
			ICompteEntity compteSrc = null;
			try {
				compteSrc = this.getCompteDao().select(unCompteIdSrc);
			} catch (ExceptionDao e) {
				throw new ErreurTechniqueException(e);
			}
			if (compteSrc == null) {
				throw new EntityIntrouvableException();
			}
			if (!unUtilisateurId.equals(compteSrc.getUtilisateurId())) {
				throw new AucunDroitException();
			}
			ICompteEntity compteDst = null;
			try {
				compteDst = this.getCompteDao().select(unCompteIdDst);
			} catch (ExceptionDao e) {
				throw new ErreurTechniqueException(e);
			}
			if (compteDst == null) {
				throw new EntityIntrouvableException();
			}
			if (!unUtilisateurId.equals(compteDst.getUtilisateurId())) {
				throw new AucunDroitException();
			}

			double montant = unMontant.doubleValue();
			// Simulation
			double soldeSrc = compteSrc.getSolde().doubleValue();
			final double decouvertSrc = compteSrc.getDecouvert() != null ? compteSrc.getDecouvert().doubleValue()
					: Double.MIN_VALUE;
			double soldeDst = compteDst.getSolde().doubleValue();
			final double decouvertDst = compteDst.getDecouvert() != null ? compteDst.getDecouvert().doubleValue()
					: Double.MIN_VALUE;

			// On retire de la source
			soldeSrc -= montant;
			// On ajoute a destination
			soldeDst += montant;
			// On regarde si les decouverts suivent
			if (soldeSrc > decouvertSrc) {
				// tout est ok
			} else {
				throw new DecouvertException();
			}
			if (soldeDst > decouvertDst) {
				// tout est ok
			} else {
				throw new DecouvertException();
			}

			Timestamp now = new Timestamp(System.currentTimeMillis());
			opSrc = new OperationEntity();
			opSrc.setCompteId(unCompteIdSrc);
			opSrc.setDate(now);
			opSrc.setMontant(Double.valueOf(-montant));
			opSrc.setLibelle("Transaction avec le comte " + unCompteIdDst);

			opDst = new OperationEntity();
			opDst.setCompteId(unCompteIdDst);
			opDst.setDate(now);
			opDst.setMontant(unMontant);
			opDst.setLibelle("Transaction avec le comte " + unCompteIdSrc);

			opSrc = this.getOperationDao().insert(opSrc);
			opDst = this.getOperationDao().insert(opDst);
			compteSrc.setSolde(Double.valueOf(soldeSrc));
			compteDst.setSolde(Double.valueOf(soldeDst));
			this.getCompteDao().update(compteSrc);
			this.getCompteDao().update(compteDst);
			resultat.add(opSrc);
			resultat.add(opDst);
		} catch (Exception e) {
			throw new ErreurTechniqueException(e);
		}
		return resultat;
	}
}