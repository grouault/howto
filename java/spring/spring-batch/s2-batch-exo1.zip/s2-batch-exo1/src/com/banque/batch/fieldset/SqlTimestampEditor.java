package com.banque.batch.fieldset;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Editeur destine a Spring qui sera gerer les java.sql.Timestamp en fonction du
 * besoin de notre UtilisateurEntity.
 */
public class SqlTimestampEditor extends SqlDateEditor {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur.
	 *
	 * @param aPattern
	 *            le pattern associe au timestamp (cf: SimpleDateFormat)
	 */
	public SqlTimestampEditor(String aPattern) {
		super(aPattern);
	}

	@Override
	public void setAsText(String pText) throws IllegalArgumentException {
		if ((pText == null) || pText.trim().isEmpty()) {
			super.setValue(null);
		} else {
			SimpleDateFormat date = new SimpleDateFormat(super.getPattern());
			date.setLenient(false);
			Date d = null;
			try {
				d = date.parse(pText);
			} catch (ParseException e) {
				SqlTimestampEditor.LOG.error("Erreur dans le parsing de la date de naissance", e);
			}
			if (d != null) {
				super.setValue(new java.sql.Timestamp(d.getTime()));
			}
		}
	}

}
