/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.xml;

import java.text.SimpleDateFormat;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * java.sql.Date adapter pour JAXB.<br/>
 * Permet de gerer proprement les dates. <br/>
 */
public class SqlDateAdapter extends XmlAdapter<String, java.sql.Date> {
	private static final Logger LOG = LogManager.getLogger();

	private static final String DATE_PATTERN = "dd/MM/yyyy";
	private SimpleDateFormat dateFormat;

	/**
	 * Constructor of the object.
	 */
	public SqlDateAdapter() {
		super();
		this.dateFormat = new SimpleDateFormat(SqlDateAdapter.DATE_PATTERN);
		this.dateFormat.setLenient(false);
	}

	@Override
	public java.sql.Date unmarshal(String aV) throws Exception {
		SqlDateAdapter.LOG.trace("unmarshal valeur={}", aV);
		if (aV == null || aV.trim().isEmpty()) {
			return null;
		}
		java.util.Date result = null;
		// SimpleDateFormat n'etant pas thread safe il est preferable de
		// l'utiliser dans un bloque synchronise
		synchronized (this.dateFormat) {
			result = this.dateFormat.parse(aV);
		}
		java.sql.Date resultat = null;
		if (result != null) {
			resultat = new java.sql.Date(result.getTime());
		}
		SqlDateAdapter.LOG.trace("unmarshal resultat={}", resultat);
		return resultat;

	}

	@Override
	public String marshal(java.sql.Date aV) throws Exception {
		SqlDateAdapter.LOG.trace("marshal valeur={}", aV);
		if (aV == null) {
			return null;
		}
		String result = null;
		// SimpleDateFormat n'etant pas thread safe il est preferable de
		// l'utiliser dans un bloque synchronise
		synchronized (this.dateFormat) {
			// java.sql.Date herite de java.util.Date
			result = this.dateFormat.format(aV);
		}
		SqlDateAdapter.LOG.trace("marshal resultat={}", result);
		return result;
	}

}
