/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.entity;

import java.sql.Timestamp;

/**
 * Represente une operation.
 */
public interface IOperationEntity extends IEntity {

	/**
	 * Recupere la propriete <i>compteId</i>.
	 *
	 * @return the compteId la valeur de la propriete.
	 */
	Integer getCompteId();

	/**
	 * Fixe la propriete <i>compteId</i>.
	 *
	 * @param pCompteId
	 *            la nouvelle valeur pour la propriete compteId.
	 */
	void setCompteId(Integer pCompteId);

	/**
	 * Recupere la date de creation de l'operation
	 *
	 * @return la date de creation de l'operation
	 */
	Timestamp getDate();

	/**
	 * Recupere le libelle de l'operation
	 *
	 * @return le libelle de l'operation
	 */
	String getLibelle();

	/**
	 * Recupere le montant de l'operation
	 *
	 * @return le montant de l'operation
	 */
	Double getMontant();

	/**
	 * Fixe la date de creation de l'operation
	 *
	 * @param uneDate
	 *            la date de creation de l'operation
	 */
	void setDate(Timestamp uneDate);

	/**
	 * Fixe le libelle de l'operation
	 *
	 * @param unLibelle
	 *            le libelle de l'operation
	 */
	void setLibelle(String unLibelle);

	/**
	 * Fixe le montant de l'operation
	 *
	 * @param unMontant
	 *            le montant de l'operation
	 */
	void setMontant(Double unMontant);

}