/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.banque.dao.ex.ExceptionDao;
import com.banque.dao.util.OperationJdbcMapper;
import com.banque.entity.IOperationEntity;

/**
 * Gestion des operations.
 */
@Repository
public class OperationDAO extends AbstractDAO<IOperationEntity> implements IOperationDAO {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public OperationDAO() {
		super();
	}

	@Override
	protected String getTableName() {
		return "operation";
	}

	@Override
	protected String getPkName() {
		return "id";
	}

	@Override
	protected RowMapper<IOperationEntity> getMapper() {
		return new OperationJdbcMapper();
	}

	@Override
	protected String getAllColumnNames() {
		return "id,libelle,montant,date,compteId";
	}

	@Override
	protected PreparedStatement buildStatementForInsert(IOperationEntity pUneEntite, Connection connexion)
			throws SQLException {

		PreparedStatement ps = connexion.prepareStatement(
				"insert into " + this.getTableName() + " (libelle, montant, date, compteId) values (?,?,?,?);",
				Statement.RETURN_GENERATED_KEYS);
		ps.setString(1, pUneEntite.getLibelle());
		ps.setDouble(2, pUneEntite.getMontant().doubleValue());
		ps.setTimestamp(3, pUneEntite.getDate());
		ps.setInt(4, pUneEntite.getCompteId().intValue());
		return ps;
	}

	@Override
	protected PreparedStatement buildStatementForUpdate(IOperationEntity pUneEntite, Connection connexion)
			throws SQLException {
		PreparedStatement ps = connexion.prepareStatement("update " + this.getTableName()
				+ " set libelle=?, montant=?, date=?, compteId=? where " + this.getPkName() + "=?;");
		ps.setString(1, pUneEntite.getLibelle());
		ps.setDouble(2, pUneEntite.getMontant().doubleValue());
		ps.setTimestamp(3, pUneEntite.getDate());
		ps.setInt(4, pUneEntite.getCompteId().intValue());
		ps.setInt(5, pUneEntite.getId().intValue());
		return ps;
	}

	@Override
	public List<IOperationEntity> selectCriteria(int unCompteId, Date unDebut, Date uneFin, Boolean pCreditDebit)
			throws ExceptionDao {
		List<IOperationEntity> result = new ArrayList<IOperationEntity>();
		OperationDAO.LOG.debug("selectCriteria sur {} unCompteId={} unDebut={} uneFin={} pCreditDebit={}",
				this.getClass(), String.valueOf(unCompteId), String.valueOf(unDebut), String.valueOf(uneFin),
				String.valueOf(pCreditDebit));
		try {
			StringBuilder request = new StringBuilder();
			request.append("select ").append(this.getAllColumnNames()).append(" from ");
			request.append(this.getTableName());
			request.append(" where compteId=?");
			List<Object> gaps = new ArrayList<Object>();
			gaps.add(Integer.valueOf(unCompteId));
			if (unDebut != null && uneFin == null) {
				request.append(" and date >= ?");
				gaps.add(unDebut);
			}

			if (uneFin != null && unDebut == null) {
				request.append(" and date <= ?");
				gaps.add(uneFin);
			}

			if (uneFin != null && unDebut != null) {
				request.append(" and date between ? and ?");
				gaps.add(unDebut);
				gaps.add(uneFin);
			}

			if (pCreditDebit != null) {
				if (pCreditDebit.booleanValue()) {
					request.append(" and montant >= 0");
				} else {
					request.append(" and montant <= 0");
				}
			}
			request.append(" order by date DESC;");
			OperationDAO.LOG.debug("selectCriteria sur {} requete={}", this.getClass(), request.toString());
			result = this.getJdbcTemplate().query(request.toString(), this.getMapper(),
					gaps.toArray(new Object[gaps.size()]));
		} catch (EmptyResultDataAccessException e) {
			return result;
		} catch (Exception e) {
			throw new ExceptionDao(e);
		}
		return result;
	}

}