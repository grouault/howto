/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.generator;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Classe utilitaire qui va lire les fichiers afin d'en sortir les donnees sous
 * forme de List ou de Map.
 */
public final class BanqueFileReader {
	private static final Logger LOG = LogManager.getLogger();

	/** Chemin racine pour les fichiers. */
	public static final String ROOT = "T:/TempFormation/Spring-Batch-Solutions/s1-batch-exo1";

	/** Chemin vers le fichier nom. */
	private static final Path PATH_NOM = Paths.get(BanqueFileReader.ROOT, "ressources", "noms.txt");
	/** Chemin vers le fichier prenom pour homes. */
	private static final Path PATH_PRENOM_H = Paths.get(BanqueFileReader.ROOT, "ressources", "prenomH.txt");
	/** Chemin vers le fichier prenom pour femmes. */
	private static final Path PATH_PRENOM_F = Paths.get(BanqueFileReader.ROOT, "ressources", "prenomF.txt");
	/** Chemin vers le fichier ville. */
	private static final Path PATH_VILLE = Paths.get(BanqueFileReader.ROOT, "ressources", "ville.txt");
	/** Chemin vers le fichier adresse. */
	private static final Path PATH_ADDRESS = Paths.get(BanqueFileReader.ROOT, "ressources", "address.txt");

	/** Charset a utiliser. */
	// private static final Charset CHARSET = Charset.forName("UTF-8");
	private static final Charset CHARSET = StandardCharsets.UTF_8;

	/**
	 * Constructeur.
	 */
	private BanqueFileReader() {
		throw new IllegalAccessError("Classe utilitaire");
	}

	/**
	 * Lecture des noms.
	 *
	 * @return les noms.
	 */
	public static List<String> lireNom() {
		try {
			return Files.readAllLines(BanqueFileReader.PATH_NOM, BanqueFileReader.CHARSET);
			// return BanqueFileReader.lire(BanqueFileReader.PATH_NOM);
		} catch (IOException e) {
			BanqueFileReader.LOG.error("Erreur lors de la lecture du fichier " + BanqueFileReader.PATH_NOM, e);
		}
		return Collections.emptyList();
	}

	/**
	 * Lecture des prenoms hommes.
	 *
	 * @return les prenoms hommes.
	 */
	public static List<String> lirePrenomHomme() {
		try {
			// return Files.readAllLines(BanqueFileReader.PATH_PRENOM_H,
			// BanqueFileReader.CHARSET);
			return BanqueFileReader.lire(BanqueFileReader.PATH_PRENOM_H);
		} catch (IOException e) {
			BanqueFileReader.LOG.error("Erreur lors de la lecture du fichier " + BanqueFileReader.PATH_PRENOM_H, e);
		}
		return Collections.emptyList();
	}

	/**
	 * Lecture des prenoms femmes.
	 *
	 * @return les prenoms femmes.
	 */
	public static List<String> lirePrenomFemmes() {
		try {
			// return Files.readAllLines(BanqueFileReader.PATH_PRENOM_F,
			// BanqueFileReader.CHARSET);
			return BanqueFileReader.lire(BanqueFileReader.PATH_PRENOM_F);
		} catch (IOException e) {
			BanqueFileReader.LOG.error("Erreur lors de la lecture du fichier " + BanqueFileReader.PATH_PRENOM_F, e);
		}
		return Collections.emptyList();
	}

	/**
	 * Lecture des adresses.
	 *
	 * @return les adresses.
	 */
	public static List<String> lireAdresses() {
		try {
			// return Files.readAllLines(BanqueFileReader.PATH_ADDRESS,
			// BanqueFileReader.CHARSET);
			return BanqueFileReader.lire(BanqueFileReader.PATH_ADDRESS);
		} catch (IOException e) {
			BanqueFileReader.LOG.error("Erreur lors de la lecture du fichier " + BanqueFileReader.PATH_ADDRESS, e);
		}
		return Collections.emptyList();
	}

	/**
	 * Lecture des villes.
	 *
	 * @return les villes.
	 */
	public static Map<Integer, List<String>> lireVilles() {
		Map<Integer, List<String>> result = new HashMap<Integer, List<String>>();
		try (BufferedReader br = Files.newBufferedReader(BanqueFileReader.PATH_VILLE, BanqueFileReader.CHARSET);) {
			String ligne = null;
			Integer dernierCp = null;
			int id = 0;
			while ((ligne = br.readLine()) != null) {
				if ((id % 2) == 0) {
					// un cp
					try {
						dernierCp = Integer.valueOf(ligne);
					} catch (NumberFormatException e) {
						BanqueFileReader.LOG
						.error("Ligne " + id + " : Le code postal " + ligne + " n'est pas un chiffre ", e);
						break;
					}
				} else {
					// une ville
					List<String> villes = result.get(dernierCp);
					if (villes == null) {
						villes = new ArrayList<String>();
						result.put(dernierCp, villes);
					}
					villes.add(ligne);
				}
				id++;
			}
		} catch (IOException e) {
			BanqueFileReader.LOG.error("Erreur lors de la lecture du fichier " + BanqueFileReader.PATH_VILLE, e);
		}

		return result;
	}

	/**
	 * Lecture des fichiers ligne a ligne.
	 *
	 * @return les lignes du fichier
	 * @throws IOException
	 *             si une erreur survient
	 */
	private static List<String> lire(Path unPath) throws IOException {
		List<String> result = new ArrayList<String>();
		int id = 0;
		try (BufferedReader br = Files.newBufferedReader(unPath, BanqueFileReader.CHARSET);) {
			String ligne = null;
			while ((ligne = br.readLine()) != null) {
				result.add(ligne);
				id++;
			}
		} catch (IOException e) {
			throw new IOException("Erreur lors de la lecture du fichier " + unPath + " ligne " + id, e);
		}

		return result;
	}
}
