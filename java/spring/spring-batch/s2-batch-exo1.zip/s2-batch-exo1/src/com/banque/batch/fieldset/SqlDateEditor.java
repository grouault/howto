package com.banque.batch.fieldset;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Editeur destine a Spring qui sera gerer les java.sql.Date en fonction du
 * besoin de notre UtilisateurEntity.
 */
public class SqlDateEditor extends PropertyEditorSupport {
	private static final Logger LOG = LogManager.getLogger();
	private String pattern;

	/**
	 * Constructeur.
	 *
	 * @param aPattern
	 *            le pattern associe a la date (cf: SimpleDateFormat)
	 */
	public SqlDateEditor(String aPattern) {
		this.pattern = aPattern;
	}

	@Override
	public void setAsText(String pText) throws IllegalArgumentException {
		if ((pText == null) || pText.trim().isEmpty()) {
			super.setValue(null);
		} else {
			SimpleDateFormat date = new SimpleDateFormat(this.pattern);
			date.setLenient(false);
			Date d = null;
			try {
				d = date.parse(pText);
			} catch (ParseException e) {
				SqlDateEditor.LOG.error("Erreur dans le parsing de la date de naissance", e);
			}
			if (d != null) {
				super.setValue(new java.sql.Date(d.getTime()));
			}
		}
	}

	/**
	 * Recupere le pattern associe a l'editeur.
	 *
	 * @return le pattern associe a l'editeur.
	 */
	protected final String getPattern() {
		return this.pattern;
	}

}
