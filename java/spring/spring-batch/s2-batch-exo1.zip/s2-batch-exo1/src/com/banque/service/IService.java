/**
 * Copyright : Ferret Renaud 2002 <br/>
 *
 * @version 1.0<br/>
 */
package com.banque.service;

/**
 * Un service.
 */
public interface IService {
	// Interface de marquage
}