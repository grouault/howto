package com.banque;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Exemple.
 */
public final class Main {
	/** Main log. */
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur.
	 */
	private Main() {
		super();
		Main.LOG.error("Ne pas utiliser le constructeur");
	}

	/**
	 * Exemple de fonctionnement.
	 *
	 * @param args
	 *            ne sert a rien
	 */
	public static void main(String[] args) {
		Main.LOG.info("-- Debut -- ");
		// TODO Recuperer la session factory
		try {
			// TODO Ouvrir une session
			// Pour le moment on ne fait rien
			// Main.LOG.info("Session hashCode={}",
			// Integer.valueOf(session.hashCode()));
		} catch (Exception e) {
			Main.LOG.fatal("Erreur", e);
			System.exit(-1);
		}
		Main.LOG.info("-- Fin -- ");
		System.exit(0);
	}
}
