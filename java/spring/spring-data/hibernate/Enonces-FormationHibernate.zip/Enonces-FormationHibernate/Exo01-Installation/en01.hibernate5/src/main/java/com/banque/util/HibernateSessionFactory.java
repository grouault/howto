package com.banque.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SessionFactory;

/**
 * Factory hibernate 5.
 *
 * @since Hibernate 5
 */
public final class HibernateSessionFactory {

	private static final Logger LOG = LogManager.getLogger();

	private static SessionFactory sessionFactory;

	/**
	 * Constructeur de l'objet.
	 */
	private HibernateSessionFactory() {
		super();
		HibernateSessionFactory.LOG.error("Ne pas utiliser le constructeur");
	}

	// TODO Coder votre methode getSessionFactory

}
