package com.banque;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.banque.util.HibernateSessionFactory;

/**
 * Exemple.
 */
public final class Main {
	/** Main log. */
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur.
	 */
	private Main() {
		super();
		Main.LOG.error("Ne pas utiliser le constructeur");
	}

	/**
	 * Exemple de fonctionnement.
	 *
	 * @param args
	 *            ne sert a rien
	 */
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		Main.LOG.info("-- Debut -- ");
		SessionFactory sf = HibernateSessionFactory.getSessionFactory();
		try (Session session = sf.openSession();) {
			// Pour le moment on ne fait rien
			Main.LOG.info("Session hashCode={}", Integer.valueOf(session.hashCode()));
		} catch (Exception e) {
			Main.LOG.fatal("Erreur", e);
			System.exit(-1);
		} finally {
			sf.close();
		}
		Main.LOG.info("-- Fin -- {} ms", Long.valueOf(System.currentTimeMillis() - start));
		System.exit(0);
	}
}
