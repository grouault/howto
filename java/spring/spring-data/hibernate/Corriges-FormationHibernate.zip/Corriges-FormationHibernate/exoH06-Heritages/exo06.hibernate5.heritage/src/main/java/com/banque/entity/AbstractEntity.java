package com.banque.entity;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * Classe abstraite qui represente toutes les entites. <br/>
 *
 * Permet de regrouper la gestion de la clef primaire.
 */
@MappedSuperclass
public abstract class AbstractEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	// En Hibernate5, AUTO ne marche pas avec MySQL
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	/**
	 * Constructeur de l'objet.
	 */
	protected AbstractEntity() {
		this(null);
	}

	/**
	 * Constructeur de l'objet.
	 *
	 * @param unId
	 *            l'id d'un compte
	 */
	protected AbstractEntity(Integer unId) {
		super();
		this.setId(unId);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getName());
		builder.append(" [Id=");
		builder.append(this.getId());
		builder.append(']');
		return builder.toString();
	}

	@Override
	public int hashCode() {
		if (this.getId() != null) {
			return (this.getClass().getName() + "-" + this.getId()).hashCode();
		}
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (obj == this) {
			return true;
		}
		// Un UtilisateurEntity qui a le meme id qu'un CompteEntity ne sont pas
		// identiques
		if (obj instanceof AbstractEntity && obj.getClass() == this.getClass()) {
			return ((AbstractEntity) obj).getId() == this.getId()
					|| ((AbstractEntity) obj).getId().equals(this.getId());
		}
		return false;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete id
	 */
	public Integer getId() {
		return this.id;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pId
	 *            la nouvelle valeur pour l'attribut id
	 */
	public void setId(Integer pId) {
		this.id = pId;
	}

}