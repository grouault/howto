package com.banque.dao;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.banque.dao.ex.ExceptionDao;
import com.banque.entity.AbstractEntity;

/**
 * Un exemple de DAO generique. <br/>
 *
 * @param <T>
 *            Le type d'element manipule
 */
abstract class AbstractDAO<T extends AbstractEntity> {
	private static final Logger LOG = LogManager.getLogger();

	private Class<T> entityClass;

	/**
	 * Constructeur de l'objet.
	 */
	protected AbstractDAO() {
		super();
	}

	/**
	 * Donne la classe associee a l'entite cible par ce DAO.
	 *
	 * @return la classe associee a l'entite cible.
	 */
	@SuppressWarnings("unchecked")
	protected Class<T> getEntityClass() {
		if (this.entityClass == null) {
			Type mySuperclass = this.getClass().getGenericSuperclass();
			// On prend dynamiquement le type generique passe a la classe
			Type tType = ((ParameterizedType) mySuperclass).getActualTypeArguments()[0];
			String tName = tType.getTypeName();
			try {
				this.entityClass = (Class<T>) Class.forName(tName);
			} catch (Exception e) {
				AbstractDAO.LOG.error("Impossible de trouver la classe de l'entite associe au DAO", e);
			}
		}
		return this.entityClass;
	}

	/**
	 * Insert l'objet dans la base.
	 *
	 * @param uneEntite
	 *            l'objet a inserer
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @return l'objet insere
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public T insert(T uneEntite, Session uneSession) throws ExceptionDao {
		AbstractDAO.LOG.debug("insert {}", uneEntite);
		if (uneEntite == null) {
			return null;
		}
		Transaction tx = uneSession.beginTransaction();
		try {
			uneSession.save(uneEntite);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			throw new ExceptionDao("Probleme d'insert pour l'objet " + uneEntite.getClass().getName(), e);
		}
		return uneEntite;
	}

	/**
	 * Met a jour l'objet dans la base.
	 *
	 * @param uneEntite
	 *            l'objet a mettre a jour
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @return l'objet mis a jour
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public T update(T uneEntite, Session uneSession) throws ExceptionDao {
		AbstractDAO.LOG.debug("update {}", uneEntite);
		if (uneEntite == null) {
			return null;
		}
		Transaction tx = uneSession.beginTransaction();
		try {
			uneSession.update(uneEntite);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			throw new ExceptionDao("Probleme d'update pour l'objet " + uneEntite.getClass().getName(), e);
		}
		return uneEntite;
	}

	/**
	 * Supprime l'objet de la base.
	 *
	 * @param uneEntite
	 *            l'objet a supprimer
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public void delete(T uneEntite, Session uneSession) throws ExceptionDao {
		AbstractDAO.LOG.debug("delete {}", uneEntite);
		if (uneEntite == null) {
			throw new ExceptionDao("L'entite est null!");
		}

		Transaction tx = uneSession.beginTransaction();
		try {
			uneSession.delete(uneEntite);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			throw new ExceptionDao("Probleme de delete pour l'objet " + uneEntite.getClass().getName(), e);
		}
	}

	/**
	 * Selectionne un objet en fonction de sa clef primaire.
	 *
	 * @param unId
	 *            l'id de l'objet
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @return l'objet trouve ou null si aucun
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	@SuppressWarnings("unchecked")
	public T select(Integer unId, Session uneSession) throws ExceptionDao {
		AbstractDAO.LOG.debug("select {} avec clef {}", this.getEntityClass().getName(), unId);
		T resultat = null;
		if (unId != null) {
			try {
				resultat = (T) uneSession.get(this.getEntityClass(), unId);
				// ou
				// resultat = (T) uneSession.load(this.getEntityClass(), unId);
				// Comprendre la difference
				// http://davidmasclet.gisgraphy.com/post/2010/10/13/Hibernate-%3A-diff%C3%A9rence-entre-get()-et-load()
			} catch (Exception e) {
				throw new ExceptionDao("Probleme dans le select pour l'objet " + this.getEntityClass(), e);
			}
		}
		return resultat;
	}

}