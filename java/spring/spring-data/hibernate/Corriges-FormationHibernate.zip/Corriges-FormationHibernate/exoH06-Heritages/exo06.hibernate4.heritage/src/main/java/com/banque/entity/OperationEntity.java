package com.banque.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Le bean qui represente une operation.
 */
@Entity
@Table(name = "operation", catalog = "banque")
public class OperationEntity extends AbstractEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "date", length = 19)
	private Timestamp date;
	@Column(name = "libelle", length = 250)
	private String libelle;
	@Column(name = "montant", precision = 22, scale = 0)
	private Double montant;

	// Mise ne place des relations

	@ManyToOne
	@JoinColumn(name = "compteId", nullable = false, unique = true)
	private CompteEntity compte;

	/**
	 * Constructeur de l'objet. </br>
	 */
	public OperationEntity() {
		this(null, null, null, null);
	}

	/**
	 * Constructeur de l'objet. </br>
	 *
	 * @param pId
	 *            unid
	 * @param pDate
	 *            l'id d'un compte
	 * @param pLibelle
	 *            le libelle du compte
	 * @param pMontant
	 *            un montant
	 */
	public OperationEntity(Integer pId, Timestamp pDate, String pLibelle, Double pMontant) {
		super(pId);
		this.setDate(pDate);
		this.setLibelle(pLibelle);
		this.setMontant(pMontant);
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete libelle
	 */
	public String getLibelle() {
		return this.libelle;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pLibelle
	 *            la nouvelle valeur pour l'attribut libelle
	 */
	public void setLibelle(String pLibelle) {
		this.libelle = pLibelle;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete montant
	 */
	public Double getMontant() {
		return this.montant;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pMontant
	 *            la nouvelle valeur pour l'attribut montant
	 */
	public void setMontant(Double pMontant) {
		this.montant = pMontant;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete date
	 */
	public Timestamp getDate() {
		return this.date;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut compte
	 */
	public CompteEntity getCompte() {
		return this.compte;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pCompte
	 *            la nouvelle valeur de l'attribut compte
	 */
	public void setCompte(CompteEntity pCompte) {
		this.compte = pCompte;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pDate
	 *            la propriete date
	 */
	public void setDate(Timestamp pDate) {
		if (pDate == null) {
			this.date = new Timestamp(System.currentTimeMillis());
		} else {
			this.date = pDate;
		}
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.delete(builder.length() - 1, builder.length());
		builder.append(", date=");
		builder.append(this.getDate());
		builder.append(", libelle=");
		builder.append(this.getLibelle());
		builder.append(", montant=");
		builder.append(this.getMontant());
		if (this.getCompte() != null) {
			builder.append(", compteId=");
			builder.append(this.getCompte().getClass().getSimpleName());
			builder.append('-');
			builder.append(this.getCompte().getId());
		} else {
			builder.append(", NO compte");
		}
		builder.append("]");
		return builder.toString();
	}

}