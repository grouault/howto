package com.banque.entity;

import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.DiscriminatorFormula;

/**
 * Le bean qui represente un Compte.
 */
@Entity
@Table(name = "compte")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorFormula("case when taux is null then 'N' else 'T' end")
@DiscriminatorValue(value = "N")
public class CompteEntity extends AbstractEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "libelle", length = 250)
	private String libelle;
	@Column(name = "solde", precision = 10)
	private BigDecimal solde;
	@Column(name = "decouvert", precision = 10)
	private BigDecimal decouvert;

	// Mise ne place des relations
	// Ne pas oublier qu'un Set ne conserve pas l'ordre
	@OneToMany(mappedBy = "compte", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<OperationEntity> operations;
	@ManyToOne
	@JoinColumn(name = "utilisateurId", nullable = false, unique = true)
	private UtilisateurEntity utilisateur;

	/**
	 * Constructeur de l'objet. </br>
	 */
	public CompteEntity() {
		this(null, null, null, null);
	}

	/**
	 * Constructeur de l'objet. </br>
	 *
	 * @param pId
	 *            l'id d'un compte
	 * @param pLibelle
	 *            le libelle du compte
	 * @param pSolde
	 *            le solde du compte
	 * @param pDecouvert
	 *            le decouvert du compte
	 */
	public CompteEntity(Integer pId, String pLibelle, BigDecimal pSolde, BigDecimal pDecouvert) {
		super(pId);
		this.setLibelle(pLibelle);
		this.setSolde(pSolde);
		this.setDecouvert(pDecouvert);
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete libelle
	 */
	public String getLibelle() {
		return this.libelle;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pLibelle
	 *            la nouvelle valeur pour l'attribut libelle
	 */
	public void setLibelle(String pLibelle) {
		this.libelle = pLibelle;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete solde
	 */
	public BigDecimal getSolde() {
		return this.solde;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pSolde
	 *            la nouvelle valeur pour l'attribut solde
	 */
	public void setSolde(BigDecimal pSolde) {
		this.solde = pSolde;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete decouvert
	 */
	public BigDecimal getDecouvert() {
		return this.decouvert;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pDecouvert
	 *            la nouvelle valeur pour l'attribut decouvert
	 */
	public void setDecouvert(BigDecimal pDecouvert) {
		this.decouvert = pDecouvert;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.delete(builder.length() - 1, builder.length());
		builder.append(", libelle=");
		builder.append(this.getLibelle());
		builder.append(", solde=");
		builder.append(this.getSolde());
		builder.append(", decouvert=");
		builder.append(this.getDecouvert());
		if (this.getUtilisateur() != null) {
			builder.append(", utilisateurId=");
			builder.append(this.getUtilisateur().getId());
		} else {
			builder.append(", NO utilisateur");
		}
		if (this.getOperations() != null && !this.getOperations().isEmpty()) {
			builder.append(", operationIds=[");
			for (OperationEntity lOp : this.getOperations()) {
				builder.append(lOp.getId());
				builder.append(',');
			}
			builder.delete(builder.length() - 1, builder.length());
			builder.append(']');
		} else {
			builder.append(", NO operation");
		}
		builder.append(']');
		return builder.toString();
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut operations
	 */
	public Set<OperationEntity> getOperations() {
		return this.operations;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pOperations
	 *            la nouvelle valeur de l'attribut operations
	 */
	public void setOperations(Set<OperationEntity> pOperations) {
		this.operations = pOperations;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut utilisateur
	 */
	public UtilisateurEntity getUtilisateur() {
		return this.utilisateur;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pUtilisateur
	 *            la nouvelle valeur de l'attribut utilisateur
	 */
	public void setUtilisateur(UtilisateurEntity pUtilisateur) {
		this.utilisateur = pUtilisateur;
	}

}