package com.banque.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 * Le bean qui represente un Compte remunere. <br/>
 *
 * NE PAS OUBLIER DE placer la classe dans le mapping.
 */
@Entity
@DiscriminatorValue(value = "T")
public class CompteRemunereEntity extends CompteEntity {

	private static final long serialVersionUID = 1L;

	@Column(name = "taux", precision = 5)
	private BigDecimal taux;

	/**
	 * Constructeur de l'objet. <br>
	 */
	public CompteRemunereEntity() {
		this(null, null, null, null, null);
	}

	/**
	 * Constructeur de l'objet. <br>
	 *
	 * @param unId
	 *            l'id d'un compte
	 * @param unLibelle
	 *            le libelle du compte
	 * @param unSolde
	 *            le solde du compte
	 * @param unDecouvert
	 *            le decouvert du compte
	 * @param unTaux
	 *            un taux
	 */
	public CompteRemunereEntity(Integer unId, String unLibelle, BigDecimal unSolde, BigDecimal unDecouvert,
			BigDecimal unTaux) {
		super(unId, unLibelle, unSolde, unDecouvert);
		this.setTaux(unTaux);
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete taux
	 */
	public BigDecimal getTaux() {
		return this.taux;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pTaux
	 *            la nouvelle valeur pour l'attribut taux
	 */
	public void setTaux(BigDecimal pTaux) {
		this.taux = pTaux;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.delete(builder.length() - 1, builder.length());
		builder.append(",taux=");
		builder.append(this.getTaux());
		builder.append(']');
		return builder.toString();
	}

}