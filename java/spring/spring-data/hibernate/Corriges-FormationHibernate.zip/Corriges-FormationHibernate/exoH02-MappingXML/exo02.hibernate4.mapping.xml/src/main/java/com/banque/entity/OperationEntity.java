package com.banque.entity;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Le bean qui represente une operation.
 */
public class OperationEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
	private Timestamp date;
	private String libelle;
	private Double montant;
	private Integer compteId;

	/**
	 * Constructeur de l'objet. </br>
	 */
	public OperationEntity() {
		this(null, null, null, null);
	}

	/**
	 * Constructeur de l'objet. </br>
	 *
	 * @param pId
	 *            unid
	 * @param pDate
	 *            l'id d'un compte
	 * @param pLibelle
	 *            le libelle du compte
	 * @param pMontant
	 *            un montant
	 */
	public OperationEntity(Integer pId, Timestamp pDate, String pLibelle, Double pMontant) {
		super();
		this.setId(pId);
		this.setDate(pDate);
		this.setLibelle(pLibelle);
		this.setMontant(pMontant);
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete libelle
	 */
	public String getLibelle() {
		return this.libelle;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pLibelle
	 *            la nouvelle valeur pour l'attribut libelle
	 */
	public void setLibelle(String pLibelle) {
		this.libelle = pLibelle;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete montant
	 */
	public Double getMontant() {
		return this.montant;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pMontant
	 *            la nouvelle valeur pour l'attribut montant
	 */
	public void setMontant(Double pMontant) {
		this.montant = pMontant;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete compteId
	 */
	public Integer getCompteId() {
		return this.compteId;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pCompteId
	 *            la nouvelle valeur pour l'attribut compteId
	 */
	public void setCompteId(Integer pCompteId) {
		this.compteId = pCompteId;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete date
	 */
	public Timestamp getDate() {
		return this.date;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pDate
	 *            la propriete date
	 */
	public void setDate(Timestamp pDate) {
		if (pDate == null) {
			this.date = new Timestamp(System.currentTimeMillis());
		} else {
			this.date = pDate;
		}
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getName());
		builder.append(" [id=");
		builder.append(this.getId());
		builder.append(", date=");
		builder.append(this.getDate());
		builder.append(", libelle=");
		builder.append(this.getLibelle());
		builder.append(", montant=");
		builder.append(this.getMontant());
		builder.append(", compteId=");
		builder.append(this.getCompteId());
		builder.append("]");
		return builder.toString();
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete id
	 */
	public Integer getId() {
		return this.id;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pId
	 *            la nouvelle valeur pour l'attribut id
	 */
	public void setId(Integer pId) {
		this.id = pId;
	}

	@Override
	public int hashCode() {
		if (this.getId() != null) {
			return (this.getClass().getName() + "-" + this.getId()).hashCode();
		}
		return super.hashCode();
	}

	@Override
	public boolean equals(Object pObj) {
		if (pObj == null) {
			return false;
		}
		if (pObj == this) {
			return true;
		}
		if (pObj instanceof OperationEntity) {
			return ((OperationEntity) pObj).getId() == this.getId()
					|| ((OperationEntity) pObj).getId().equals(this.getId());
		}
		return false;
	}

}