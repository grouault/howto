package com.banque.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.OperationEntity;

/**
 * Gestion des operations.
 */
public class OperationDAO extends AbstractDAO<OperationEntity> {
	@SuppressWarnings("unused")
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public OperationDAO() {
		super();
	}
}