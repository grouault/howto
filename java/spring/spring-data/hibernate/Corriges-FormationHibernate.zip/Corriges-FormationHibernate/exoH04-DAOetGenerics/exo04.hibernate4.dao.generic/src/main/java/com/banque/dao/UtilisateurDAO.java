package com.banque.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.UtilisateurEntity;

/**
 * Gestion des operations.
 */
public class UtilisateurDAO extends AbstractDAO<UtilisateurEntity> {
	@SuppressWarnings("unused")
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public UtilisateurDAO() {
		super();
	}
}