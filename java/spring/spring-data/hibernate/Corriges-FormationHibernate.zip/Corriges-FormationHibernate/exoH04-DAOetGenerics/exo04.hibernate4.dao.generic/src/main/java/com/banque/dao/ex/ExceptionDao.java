package com.banque.dao.ex;

/**
 * Exception liee aux DAO.
 */
public class ExceptionDao extends Exception {
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur.
	 */
	public ExceptionDao() {
		super();
	}

	/**
	 * Constructeur.
	 *
	 * @param message
	 *            un message
	 * @param cause
	 *            une cause
	 */
	public ExceptionDao(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructeur.
	 *
	 * @param message
	 *            un message
	 */
	public ExceptionDao(String message) {
		super(message);
	}

	/**
	 * Constructeur.
	 *
	 * @param cause
	 *            une cause
	 */
	public ExceptionDao(Throwable cause) {
		super(cause);
	}

}
