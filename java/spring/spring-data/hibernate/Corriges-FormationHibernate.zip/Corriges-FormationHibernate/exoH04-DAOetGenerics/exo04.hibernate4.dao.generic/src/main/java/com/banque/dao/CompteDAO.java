package com.banque.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.banque.entity.CompteEntity;

/**
 * Gestion des comptes.
 */
public class CompteDAO extends AbstractDAO<CompteEntity> {
	@SuppressWarnings("unused")
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public CompteDAO() {
		super();
	}

}