package com.banque.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Le bean qui represente un Compte.
 */
@Entity
@Table(name = "compte")
public class CompteEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// En Hibernate 5, AUTO ne marche pas avec MySQL, prendre IDENTITY
	private Integer id;

	@Column(name = "libelle", length = 250)
	private String libelle;
	@Column(name = "solde", precision = 10)
	private BigDecimal solde;
	@Column(name = "decouvert", precision = 10)
	private BigDecimal decouvert;
	@Column(name = "taux", precision = 5)
	private BigDecimal taux;
	@Column(name = "utilisateurId", nullable = false)
	private Integer utilisateurId;

	/**
	 * Constructeur de l'objet. </br>
	 */
	public CompteEntity() {
		this(null, null, null, null, null);
	}

	/**
	 * Constructeur de l'objet. </br>
	 *
	 * @param pId
	 *            l'id d'un compte
	 * @param pLibelle
	 *            le libelle du compte
	 * @param pSolde
	 *            le solde du compte
	 * @param pDecouvert
	 *            le decouvert du compte
	 * @param pTaux
	 *            un taux
	 */
	public CompteEntity(Integer pId, String pLibelle, BigDecimal pSolde, BigDecimal pDecouvert, BigDecimal pTaux) {
		super();
		this.setId(pId);
		this.setLibelle(pLibelle);
		this.setSolde(pSolde);
		this.setDecouvert(pDecouvert);
		this.setTaux(pTaux);
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete libelle
	 */
	public String getLibelle() {
		return this.libelle;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pLibelle
	 *            la nouvelle valeur pour l'attribut libelle
	 */
	public void setLibelle(String pLibelle) {
		this.libelle = pLibelle;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete solde
	 */
	public BigDecimal getSolde() {
		return this.solde;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pSolde
	 *            la nouvelle valeur pour l'attribut solde
	 */
	public void setSolde(BigDecimal pSolde) {
		this.solde = pSolde;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete decouvert
	 */
	public BigDecimal getDecouvert() {
		return this.decouvert;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pDecouvert
	 *            la nouvelle valeur pour l'attribut decouvert
	 */
	public void setDecouvert(BigDecimal pDecouvert) {
		this.decouvert = pDecouvert;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete taux
	 */
	public BigDecimal getTaux() {
		return this.taux;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pTaux
	 *            la nouvelle valeur pour l'attribut taux
	 */
	public void setTaux(BigDecimal pTaux) {
		this.taux = pTaux;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete utilisateurId
	 */
	public Integer getUtilisateurId() {
		return this.utilisateurId;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pUtilisateurId
	 *            la nouvelle valeur pour l'attribut utilisateurId
	 */
	public void setUtilisateurId(Integer pUtilisateurId) {
		this.utilisateurId = pUtilisateurId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getName());
		builder.append(" [id=");
		builder.append(this.getId());
		builder.append(", libelle=");
		builder.append(this.getLibelle());
		builder.append(", solde=");
		builder.append(this.getSolde());
		builder.append(", decouvert=");
		builder.append(this.getDecouvert());
		builder.append(", taux=");
		builder.append(this.getTaux());
		builder.append(", utilisateurId=");
		builder.append(this.getUtilisateurId());
		builder.append("]");
		return builder.toString();
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la propriete id
	 */
	public Integer getId() {
		return this.id;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pId
	 *            la nouvelle valeur pour l'attribut id
	 */
	public void setId(Integer pId) {
		this.id = pId;
	}

	@Override
	public int hashCode() {
		if (this.getId() != null) {
			return (this.getClass().getName() + "-" + this.getId()).hashCode();
		}
		return super.hashCode();
	}

	@Override
	public boolean equals(Object pObj) {
		if (pObj == null) {
			return false;
		}
		if (pObj == this) {
			return true;
		}
		if (pObj instanceof CompteEntity) {
			return ((CompteEntity) pObj).getId() == this.getId() || ((CompteEntity) pObj).getId().equals(this.getId());
		}
		return false;
	}

}