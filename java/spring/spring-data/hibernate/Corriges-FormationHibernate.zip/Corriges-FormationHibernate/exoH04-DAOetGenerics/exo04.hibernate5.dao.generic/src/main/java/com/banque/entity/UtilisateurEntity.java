package com.banque.entity;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Le bean qui represente un utilisateur. <br>
 */
@Entity
@Table(name = "utilisateur", catalog = "banque")
public class UtilisateurEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// En Hibernate 5, AUTO ne marche pas avec MySQL, prendre IDENTITY
	private Integer id;

	@Column(name = "login", length = 120, nullable = false)
	private String login;
	@Column(name = "password", length = 120, nullable = false)
	private String password;
	@Column(name = "nom", length = 120)
	private String nom;
	@Column(name = "prenom", length = 120)
	private String prenom;
	@Column(name = "sex")
	private Boolean sex;
	@Column(name = "derniereConnection", length = 19)
	private Timestamp derniereConnection;
	@Column(name = "dateDeNaissance", length = 10)
	private Date dateDeNaissance;
	@Column(name = "adresse", length = 500)
	private String adresse;
	@Column(name = "telephone", length = 20)
	private String telephone;
	@Column(name = "codePostal")
	private Integer codePostal;

	/**
	 * Constructeur de l'objet. <br>
	 */
	public UtilisateurEntity() {
		super();
	}

	@Override
	public int hashCode() {
		if (this.getId() != null) {
			return (this.getClass().getName() + "-" + this.getId()).hashCode();
		}
		return super.hashCode();
	}

	@Override
	public boolean equals(Object pObj) {
		if (pObj == null) {
			return false;
		}
		if (pObj == this) {
			return true;
		}
		if (pObj instanceof UtilisateurEntity) {
			return ((UtilisateurEntity) pObj).getId() == this.getId()
					|| ((UtilisateurEntity) pObj).getId().equals(this.getId());
		}
		return false;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut id
	 */
	public Integer getId() {
		return this.id;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pId
	 *            la nouvelle valeur de l'attribut id
	 */
	public void setId(Integer pId) {
		this.id = pId;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut login
	 */
	public String getLogin() {
		return this.login;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pLogin
	 *            la nouvelle valeur de l'attribut login
	 */
	public void setLogin(String pLogin) {
		this.login = pLogin;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut password
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pPassword
	 *            la nouvelle valeur de l'attribut password
	 */
	public void setPassword(String pPassword) {
		this.password = pPassword;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut nom
	 */
	public String getNom() {
		return this.nom;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pNom
	 *            la nouvelle valeur de l'attribut nom
	 */
	public void setNom(String pNom) {
		this.nom = pNom;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut prenom
	 */
	public String getPrenom() {
		return this.prenom;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pPrenom
	 *            la nouvelle valeur de l'attribut prenom
	 */
	public void setPrenom(String pPrenom) {
		this.prenom = pPrenom;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut sex
	 */
	public Boolean getSex() {
		return this.sex;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pSex
	 *            la nouvelle valeur de l'attribut sex
	 */
	public void setSex(Boolean pSex) {
		this.sex = pSex;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut derniereConnection
	 */
	public Timestamp getDerniereConnection() {
		return this.derniereConnection;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pDerniereConnection
	 *            la nouvelle valeur de l'attribut derniereConnection
	 */
	public void setDerniereConnection(Timestamp pDerniereConnection) {
		this.derniereConnection = pDerniereConnection;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut dateDeNaissance
	 */
	public Date getDateDeNaissance() {
		return this.dateDeNaissance;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pDateDeNaissance
	 *            la nouvelle valeur de l'attribut dateDeNaissance
	 */
	public void setDateDeNaissance(Date pDateDeNaissance) {
		this.dateDeNaissance = pDateDeNaissance;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut adresse
	 */
	public String getAdresse() {
		return this.adresse;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pAdresse
	 *            la nouvelle valeur de l'attribut adresse
	 */
	public void setAdresse(String pAdresse) {
		this.adresse = pAdresse;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut telephone
	 */
	public String getTelephone() {
		return this.telephone;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pTelephone
	 *            la nouvelle valeur de l'attribut telephone
	 */
	public void setTelephone(String pTelephone) {
		this.telephone = pTelephone;
	}

	/**
	 * Recupere la valeur de l'attribut.
	 *
	 * @return la valeur de l'attribut codePostal
	 */
	public Integer getCodePostal() {
		return this.codePostal;
	}

	/**
	 * Modifie la valeur de l'attribut.
	 *
	 * @param pCodePostal
	 *            la nouvelle valeur de l'attribut codePostal
	 */
	public void setCodePostal(Integer pCodePostal) {
		this.codePostal = pCodePostal;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(this.getClass().getName());
		builder.append(" [Id=");
		builder.append(this.getId());
		builder.append(", Login=");
		builder.append(this.getLogin());
		builder.append(", Password=");
		builder.append(this.getPassword());
		builder.append(", Nom=");
		builder.append(this.getNom());
		builder.append(", Prenom=");
		builder.append(this.getPrenom());
		builder.append(", Sex=");
		builder.append(this.getSex());
		builder.append(", DerniereConnection=");
		builder.append(this.getDerniereConnection());
		builder.append(", DateDeNaissance=");
		builder.append(this.getDateDeNaissance());
		builder.append(", Adresse=");
		builder.append(this.getAdresse());
		builder.append(", Telephone=");
		builder.append(this.getTelephone());
		builder.append(", CodePostal=");
		builder.append(this.getCodePostal());
		builder.append("]");
		return builder.toString();
	}

}