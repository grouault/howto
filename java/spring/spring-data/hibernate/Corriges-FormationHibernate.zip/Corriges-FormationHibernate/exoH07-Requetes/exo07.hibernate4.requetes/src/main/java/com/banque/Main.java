package com.banque;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.banque.dao.CompteDAO;
import com.banque.dao.OperationDAO;
import com.banque.dao.UtilisateurDAO;
import com.banque.entity.CompteEntity;
import com.banque.entity.OperationEntity;
import com.banque.entity.UtilisateurEntity;
import com.banque.util.HibernateSessionFactory;

/**
 * Exemple.
 */
public final class Main {
	/** Main log. */
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur.
	 */
	private Main() {
		super();
		Main.LOG.error("Ne pas utiliser le constructeur");
	}

	/**
	 * Exemple de fonctionnement.
	 *
	 * @param args
	 *            ne sert a rien
	 */
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		Main.LOG.info("-- Debut --");
		SessionFactory factory = HibernateSessionFactory.getSessionFactory();
		Session session = null;
		UtilisateurDAO utilisateurDao = new UtilisateurDAO();
		CompteDAO compteDao = new CompteDAO();
		OperationDAO operationDao = new OperationDAO();

		try {
			session = factory.openSession();
			Main.LOG.info("*************** Select ***************");
			UtilisateurEntity utilisateur = utilisateurDao.select(Integer.valueOf(1), session);
			Main.LOG.info(utilisateur);
			CompteEntity compte = compteDao.select(Integer.valueOf(12), session);
			Main.LOG.info(compte);
			OperationEntity operation = operationDao.select(Integer.valueOf(1), session);
			Main.LOG.info(operation);
			List<OperationEntity> ops = operationDao.filtrer(Integer.valueOf(12), null, null, null, null, null,
					session);
			Main.LOG.info(ops);
			List<CompteEntity> cpts00 = compteDao.filtrer(Integer.valueOf(1), null, null, null, null, session);
			Main.LOG.info(cpts00);
			Main.LOG.info("Authentification {}", utilisateurDao.authentifier("ip", "ip", session));
			Main.LOG.info("*************** Update ***************");
			Main.LOG.info("Ancien nom: {}", utilisateur.getNom());
			utilisateur.setNom(utilisateur.getNom() + "U");
			utilisateur = utilisateurDao.update(utilisateur, session);
			Main.LOG.info("Nouveau nom: {}", utilisateur.getNom());
			//
			Main.LOG.info("Ancien solde: {}", compte.getSolde());
			compte.setSolde(BigDecimal.valueOf(compte.getSolde().doubleValue() + 0.5));
			compte = compteDao.update(compte, session);
			Main.LOG.info("Nouveau solde: {}", compte.getSolde());
			//
			Main.LOG.info("Ancien montant: {}", operation.getMontant());
			operation.setMontant(Double.valueOf(operation.getMontant().doubleValue() + 0.5));
			operation = operationDao.update(operation, session);
			Main.LOG.info("Nouveau montant: {}", operation.getMontant());
			Main.LOG.info("*************** Insert ***************");
			UtilisateurEntity nU = new UtilisateurEntity();
			nU.setNom("Nouveau");
			nU.setPrenom("Nouveau");
			nU.setLogin("Nouveau");
			nU.setPassword("Nouveau");
			nU.setSex(Boolean.TRUE);
			nU = utilisateurDao.insert(nU, session);
			Main.LOG.info("Apres Insert={}", nU);
			// Avec des comptes
			UtilisateurEntity nU2 = new UtilisateurEntity();
			nU2.setNom("Nouveau");
			nU2.setPrenom("Nouveau");
			nU2.setLogin("Nouveau");
			nU2.setPassword("Nouveau");
			nU2.setSex(Boolean.TRUE);
			CompteEntity cpU2 = new CompteEntity();
			cpU2.setLibelle("Nouveau");
			cpU2.setSolde(BigDecimal.valueOf(25));
			cpU2.setUtilisateur(nU2);
			// on donne le compte a l'utilisateur
			Set<CompteEntity> cpts = new HashSet<CompteEntity>();
			cpts.add(cpU2);
			nU2.setComptes(cpts);
			nU2 = utilisateurDao.insert(nU2, session);
			// En base on aura un insert de compte et un insert d'utilisateur
			// avec le lien entre les deux
			// UNIQUEMENT parce que l'on a precise cascade = CascadeType.ALL
			Main.LOG.info("Apres Insert={}", nU2);
			//
			CompteEntity cp = new CompteEntity();
			cp.setLibelle("Nouveau");
			cp.setSolde(BigDecimal.valueOf(25));
			cp.setUtilisateur(nU);
			cp = compteDao.insert(cp, session);
			Main.LOG.info("Apres Insert={}", cp);
			//
			OperationEntity op = new OperationEntity();
			op.setLibelle("Nouveau");
			op.setMontant(Double.valueOf(50));
			op.setCompte(cp);
			op = operationDao.insert(op, session);
			Main.LOG.info("Apres Insert={}", op);

			Main.LOG.info("*************** Delete ***************");
			// Attention a l'ordre, a cause des jointures
			operationDao.delete(op, session);
			//
			compteDao.delete(cp, session);
			//
			utilisateurDao.delete(nU, session);
			utilisateurDao.delete(nU2, session);
		} catch (Exception e) {
			Main.LOG.fatal("Erreur", e);
			System.exit(-1);
		} finally {
			if (session != null) {
				session.close();
			}
			factory.close();
		}
		Main.LOG.info("-- Fin -- {} ms", Long.valueOf(System.currentTimeMillis() - start));
		System.exit(0);
	}
}
