package com.banque.dao;

import java.sql.Date;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.banque.dao.ex.ExceptionDao;
import com.banque.entity.OperationEntity;

/**
 * Gestion des operations.
 */
public class OperationDAO extends AbstractDAO<OperationEntity> {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public OperationDAO() {
		super();
	}

	/**
	 * Selectionne un ensemble d'operations en fonction des criteres donnes
	 *
	 * @param unIdCompte
	 *            obligatoire, represente un id de compte
	 * @param credit
	 *            TRUE pour les montant &gt;0, FALSE pour les &lt;0 et null pour
	 *            les deux
	 * @param montantMin
	 *            un montant minimal
	 * @param montantMax
	 *            un montant maximal
	 * @param debut
	 *            une date debut
	 * @param fin
	 *            une date de fin
	 * @param pSession
	 *            une session
	 * @return la liste des operations correspondant aux criteres ou une liste
	 *         vide si rien
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public List<OperationEntity> filtrer(Integer unIdCompte, Boolean credit, Date debut, Date fin, Double montantMin,
			Double montantMax, Session pSession) throws ExceptionDao {
		OperationDAO.LOG.debug("filtrer {} {} {} {} {} {}", unIdCompte, credit, debut, fin, montantMin, montantMax);

		if (unIdCompte == null) {
			throw new ExceptionDao("Parametres invalides");
		}

		Criteria crt = pSession.createCriteria(this.getEntityClass());
		crt.add(Restrictions.eq("compte.id", unIdCompte));
		if (credit != null) {
			if (credit.booleanValue()) {
				crt.add(Restrictions.ge("montant", Double.valueOf(0)));
			} else {
				crt.add(Restrictions.lt("montant", Double.valueOf(0)));
			}
		}
		if (debut != null && fin == null) {
			crt.add(Restrictions.le("date", debut));
		}
		if (fin != null && debut == null) {
			crt.add(Restrictions.ge("date", fin));
		}
		if (fin != null && debut != null) {
			crt.add(Restrictions.between("date", debut, fin));
		}

		if (montantMin != null && montantMax == null) {
			crt.add(Restrictions.le("montant", montantMin));
		}
		if (montantMax != null && montantMin == null) {
			crt.add(Restrictions.ge("montant", montantMax));
		}
		if (montantMax != null && montantMin != null) {
			crt.add(Restrictions.between("montant", montantMin, montantMax));
		}

		@SuppressWarnings("unchecked")
		List<OperationEntity> resultat = crt.list();
		if (resultat == null || resultat.isEmpty()) {
			return Collections.emptyList();
		}
		return resultat;
	}
}