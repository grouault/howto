package com.banque.dao;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;

import com.banque.dao.ex.ExceptionDao;
import com.banque.entity.CompteEntity;
import com.banque.entity.CompteRemunereEntity;

/**
 * Gestion des comptes.
 */
public class CompteDAO extends AbstractDAO<CompteEntity> {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public CompteDAO() {
		super();
	}

	/**
	 * Selectionne un ensemble de compte en fonction des criteres donnes
	 *
	 * @param unIdUtilisateur
	 *            obligatoire, represente un id utilisateur
	 * @param unLibelle
	 *            un libelle de compte
	 * @param unSoldeMin
	 *            un solde minimal
	 * @param unSoldeMax
	 *            un solde maximal
	 * @param unType
	 *            un type de compte (T pour Remunere, N pour normal, null pour
	 *            tous)
	 * @param pSession
	 *            une session
	 * @return la liste des comptes correspondant aux criteres ou une liste vide
	 *         si rien
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public List<CompteEntity> filtrer(Integer unIdUtilisateur, String unLibelle, BigDecimal unSoldeMin,
			BigDecimal unSoldeMax, String unType, Session pSession) throws ExceptionDao {
		CompteDAO.LOG.debug("filtrer {} {} {} {} {}", unIdUtilisateur, unLibelle, unSoldeMin, unSoldeMax);
		if (unIdUtilisateur == null) {
			throw new ExceptionDao("Parametres invalides");
		}

		// En Hibernate 5 on doit faire usage du JPA
		// Donc on recupre le CriteriaBuilder de la session
		CriteriaBuilder cb = pSession.getCriteriaBuilder();
		// On fabrique une CriteriaQuery
		CriteriaQuery<CompteEntity> crt = cb.createQuery(this.getEntityClass());
		// From
		Root<? extends CompteEntity> cpt;
		if ("T".equals(unType)) {
			cpt = crt.from(CompteRemunereEntity.class);
		} else {
			cpt = crt.from(this.getEntityClass());
		}
		crt.select(cpt);
		// Chemin vers id utilisateur
		Path<Integer> pathIdUti = cpt.get("utilisateur").get("id");
		crt.where(cb.equal(pathIdUti, unIdUtilisateur));

		if (unLibelle != null) {
			// Chemin vers libelle
			Path<String> pathLibelle = cpt.get("libelle");
			crt.where(cb.like(pathLibelle, unLibelle));
		}
		// Chemin vers solde
		Path<BigDecimal> pathSolde = cpt.get("solde");

		if (unSoldeMax != null && unSoldeMin == null) {
			crt.where(cb.lessThanOrEqualTo(pathSolde, unSoldeMax));
		}
		if (unSoldeMin != null && unSoldeMax == null) {
			crt.where(cb.greaterThanOrEqualTo(pathSolde, unSoldeMin));
		}
		if (unSoldeMin != null && unSoldeMax != null) {
			crt.where(cb.between(pathSolde, unSoldeMin, unSoldeMax));
		}

		TypedQuery<CompteEntity> query = pSession.createQuery(crt);
		List<CompteEntity> resultat = query.getResultList();
		if (resultat == null || resultat.isEmpty()) {
			return Collections.emptyList();
		}
		return resultat;
	}
}