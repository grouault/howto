package com.banque.dao;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;

import com.banque.dao.ex.ExceptionDao;
import com.banque.entity.OperationEntity;

/**
 * Gestion des operations.
 */
public class OperationDAO extends AbstractDAO<OperationEntity> {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public OperationDAO() {
		super();
	}

	/**
	 * Selectionne un ensemble d'operations en fonction des criteres donnes
	 *
	 * @param unIdCompte
	 *            obligatoire, represente un id de compte
	 * @param credit
	 *            TRUE pour les montant &gt;0, FALSE pour les &lt;0 et null pour
	 *            les deux
	 * @param montantMin
	 *            un montant minimal
	 * @param montantMax
	 *            un montant maximal
	 * @param debut
	 *            une date debut
	 * @param fin
	 *            une date de fin
	 * @param pSession
	 *            une session
	 * @return la liste des operations correspondant aux criteres ou une liste
	 *         vide si rien
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public List<OperationEntity> filtrer(Integer unIdCompte, Boolean credit, Date debut, Date fin, Double montantMin,
			Double montantMax, Session pSession) throws ExceptionDao {
		OperationDAO.LOG.debug("filtrer {} {} {} {} {} {}", unIdCompte, credit, debut, fin, montantMin, montantMax);
		if (unIdCompte == null) {
			throw new ExceptionDao("Parametres invalides");
		}

		// En Hibernate 5 on doit faire usage du JPA
		// Donc on recupre le CriteriaBuilder de la session
		CriteriaBuilder cb = pSession.getCriteriaBuilder();
		// On fabrique une CriteriaQuery
		CriteriaQuery<OperationEntity> crt = cb.createQuery(this.getEntityClass());
		// From
		Root<OperationEntity> op = crt.from(this.getEntityClass());
		crt.select(op);
		// Chemin vers id du compte
		Path<Integer> pathIdCpt = op.get("compte").get("id");
		crt.where(cb.equal(pathIdCpt, unIdCompte));
		// Chemin vers Montant
		Path<Double> pathMontant = op.get("montant");
		if (credit != null) {
			if (credit.booleanValue()) {
				crt.where(cb.ge(pathMontant, Double.valueOf(0)));
			} else {
				// crt.where(cb.le(op.get(atMontant), Double.valueOf(0)));
				crt.where(cb.le(pathMontant, Double.valueOf(0)));
			}
		}
		// Chemin vers date
		Path<Timestamp> dateCreatedPath = op.get("date");
		if (debut != null && fin == null) {
			crt.where(cb.greaterThanOrEqualTo(dateCreatedPath, new Timestamp(debut.getTime())));
		}
		if (fin != null && debut == null) {
			crt.where(cb.lessThanOrEqualTo(dateCreatedPath, new Timestamp(fin.getTime())));
		}
		if (fin != null && debut != null) {
			crt.where(cb.between(dateCreatedPath, new Timestamp(debut.getTime()), new Timestamp(fin.getTime())));
		}

		if (montantMin != null && montantMax == null) {
			crt.where(cb.greaterThanOrEqualTo(pathMontant, montantMin));
		}
		if (montantMax != null && montantMin == null) {
			crt.where(cb.lessThanOrEqualTo(pathMontant, montantMax));
		}
		if (montantMax != null && montantMin != null) {
			crt.where(cb.between(pathMontant, montantMin, montantMax));
		}

		TypedQuery<OperationEntity> query = pSession.createQuery(crt);
		List<OperationEntity> resultat = query.getResultList();
		if (resultat == null || resultat.isEmpty()) {
			return Collections.emptyList();
		}
		return resultat;
	}
}