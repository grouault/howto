package com.banque.dao;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.query.Query;

import com.banque.dao.ex.ExceptionDao;
import com.banque.entity.UtilisateurEntity;

/**
 * Gestion des operations.
 */
public class UtilisateurDAO extends AbstractDAO<UtilisateurEntity> {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public UtilisateurDAO() {
		super();
	}

	/**
	 * Authentifie un utilisateur.
	 *
	 * @param unLogin
	 *            un login
	 * @param unPassword
	 *            un mot de passe
	 * @param pSession
	 *            une session
	 * @return l'utilisateur correspondant ou null si rien
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	@SuppressWarnings("squid:S2068")
	public UtilisateurEntity authentifier(String unLogin, String unPassword, Session pSession) throws ExceptionDao {
		UtilisateurDAO.LOG.debug("authentifier {} Xxxx", unLogin);

		if (unLogin == null || unPassword == null || unLogin.trim().isEmpty() || unPassword.trim().isEmpty()) {
			throw new ExceptionDao("Parametres invalides");
		}
		// En HQL
		String request = "from " + this.getEntityClass().getName() + " where login=:unLogin and password=:unPwd";
		Query<UtilisateurEntity> query = pSession.createQuery(request, this.getEntityClass());
		query.setParameter("unLogin", unLogin);
		query.setParameter("unPwd", unPassword);
		List<UtilisateurEntity> resultat = query.getResultList();
		if (resultat == null || resultat.isEmpty()) {
			return null;
		}
		if (resultat.size() > 1) {
			throw new ExceptionDao("Plus d'un resultat trouve!");
		}
		return resultat.get(0);
	}
}