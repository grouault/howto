package com.banque.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.banque.dao.ex.ExceptionDao;
import com.banque.entity.CompteEntity;

/**
 * Gestion des comptes.
 */
public class CompteDAO {
	private static final Logger LOG = LogManager.getLogger();

	/**
	 * Constructeur de l'objet.
	 */
	public CompteDAO() {
		super();
	}

	/**
	 * Insert l'objet dans la base.
	 *
	 * @param uneEntite
	 *            l'objet a inserer
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @return l'objet insere
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public CompteEntity insert(CompteEntity uneEntite, Session uneSession) throws ExceptionDao {
		CompteDAO.LOG.debug("insert compte {}", uneEntite);
		if (uneEntite == null) {
			return null;
		}
		Transaction tx = uneSession.beginTransaction();
		try {
			uneSession.save(uneEntite);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			throw new ExceptionDao("Probleme d'insert pour l'objet " + uneEntite.getClass().getName(), e);
		}

		return uneEntite;
	}

	/**
	 * Met a jour l'objet dans la base.
	 *
	 * @param uneEntite
	 *            l'objet a mettre a jour
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @return l'objet mis a jour
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public CompteEntity update(CompteEntity uneEntite, Session uneSession) throws ExceptionDao {
		CompteDAO.LOG.debug("update compte {}", uneEntite);
		if (uneEntite == null) {
			return null;
		}
		if (uneEntite.getId() == null) {
			throw new ExceptionDao("L'entite n'a pas d'ID");
		}
		Transaction tx = uneSession.beginTransaction();
		try {
			uneSession.update(uneEntite);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			throw new ExceptionDao("Probleme d'update pour l'objet " + uneEntite.getClass().getName(), e);
		}

		return uneEntite;
	}

	/**
	 * Supprime l'objet de la base.
	 *
	 * @param uneEntite
	 *            l'objet a supprimer
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public void delete(CompteEntity uneEntite, Session uneSession) throws ExceptionDao {
		CompteDAO.LOG.debug("delete compte {}", uneEntite);
		if (uneEntite == null) {
			throw new ExceptionDao("L'entite est null!");
		}
		if (uneEntite.getId() == null) {
			throw new ExceptionDao("L'entite n'a pas d'ID");
		}

		Transaction tx = uneSession.beginTransaction();
		try {
			uneSession.delete(uneEntite);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			throw new ExceptionDao("Probleme de delete pour l'objet " + uneEntite.getClass().getName(), e);
		}
	}

	/**
	 * Selectionne un objet en fonction de sa clef primaire.
	 *
	 * @param unId
	 *            l'id de l'objet
	 * @param uneSession
	 *            la session hibernate a utiliser
	 * @return l'objet trouve ou null si aucun
	 * @throws ExceptionDao
	 *             si une erreur survient
	 */
	public CompteEntity select(Integer unId, Session uneSession) throws ExceptionDao {
		CompteDAO.LOG.debug("select unId {}", unId);
		CompteEntity resultat = null;
		if (unId != null) {
			try {
				resultat = (CompteEntity) uneSession.get(CompteEntity.class, unId);
				// ou
				// resultat = (T) uneSession.load(this.getEntityClass(), unId);
				// Comprendre la difference
				// http://davidmasclet.gisgraphy.com/post/2010/10/13/Hibernate-%3A-diff%C3%A9rence-entre-get()-et-load()
			} catch (Exception e) {
				throw new ExceptionDao("Probleme dans le select pour l'objet " + CompteEntity.class, e);
			}
		}
		return resultat;
	}

}